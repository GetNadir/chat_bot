package com.nadir.iga_chatbot_rag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IgaChatbotRagApplicationTests {

	@Test
	void contextLoads() {
	}

}
