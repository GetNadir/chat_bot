package com.nadir.iga_chatbot_rag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IgaChatbotRagApplication {

    public static void main(String[] args) {
        SpringApplication.run(IgaChatbotRagApplication.class, args);
    }

}
