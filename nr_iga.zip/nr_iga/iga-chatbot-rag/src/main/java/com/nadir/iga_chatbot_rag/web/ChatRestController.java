package com.nadir.iga_chatbot_rag.web;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nadir.iga_chatbot_rag.services.ChatAiService;


@RestController
@RequestMapping("/chat")

 public class ChatRestController {
    private ChatAiService chatAiService;


    public ChatRestController(ChatAiService chatAiService) {
        this.chatAiService = chatAiService;
    }
    @GetMapping(path = "/ask", produces = MediaType.TEXT_PLAIN_VALUE)
    public String ask(String question) {
        return chatAiService.ragChat(question);
    }
    


}
