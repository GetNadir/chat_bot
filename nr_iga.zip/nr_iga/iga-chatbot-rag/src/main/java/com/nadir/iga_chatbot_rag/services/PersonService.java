package com.nadir.iga_chatbot_rag.services;

import com.nadir.iga_chatbot_rag.entities.Person;
import com.nadir.iga_chatbot_rag.entities.PersonRepository;
import com.vaadin.flow.server.auth.AnonymousAllowed;
import com.vaadin.hilla.BrowserCallable;
import com.vaadin.hilla.crud.CrudRepositoryService;

@BrowserCallable
@AnonymousAllowed
public class PersonService extends CrudRepositoryService<Person, Long,PersonRepository> {
    
    
}
