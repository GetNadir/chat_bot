

import { TextField } from '@vaadin/react-components';
import { ChatAiService } from 'Frontend/generated/endpoints';
import React, { useState } from 'react';

import Markdown from 'react-markdown';
export default function Chat() {
    const [question, setQuestion] = useState<string>("");
    const [response, setResponse] = useState<string>("");
    async function send() {
        ChatAiService.ragChat(question).then((resp) => {
            setResponse(resp); 
    })
}


    return (
        <div >
        <h3>Chat Bot</h3>
        <div>
            <TextField style={{width:'80%'}} 
            onChange={(e => setQuestion(e.target.value))}
            />
            <button className="btn btn-primary" onClick={send}>Send</button>
            <div>
                <Markdown>{response}</Markdown>
            </div>
        </div>
        
        </div>
    );
}
