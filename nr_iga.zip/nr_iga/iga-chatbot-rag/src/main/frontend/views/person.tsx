import {AutoCrud} from "@vaadin/hilla-react-crud"  ;
import PersonModel from "Frontend/generated/com/nadir/iga/chatbot/PersonModel"  ;
export default function Person(){
    return (
       
            <AutoCrud service={PersonService} model={PersonModel} />  );
}