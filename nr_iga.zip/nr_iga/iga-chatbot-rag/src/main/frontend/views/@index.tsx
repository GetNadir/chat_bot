
import React from 'react';
import "../styles/styles.css"
import "bootstrap/dist/css/bootstrap.min.css";

export default function Index() {
    return (
        <div className='p-m'>
        <h1>home page</h1>
        </div>
    );
}
 